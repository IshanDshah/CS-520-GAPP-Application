package springmvc.model.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.Test;

import gapp.model.ApplicationStatus;
import gapp.model.dao.ApplicationStatusDao;

@Test(groups = "ApplicationStatusDaoTest")
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class ApplicationStatusDaoTest extends AbstractTransactionalTestNGSpringContextTests {

	@Autowired
	ApplicationStatusDao applicationstatusDao;

	@Test
	public void getApplicationStatus() {
/*		int counter = 0;
		
		List<ApplicationStatus> applicationStatus=applicationstatusDao.getstatus();
		for(ApplicationStatus applicationstatus:applicationStatus)
		{
			if(applicationstatus.getStudent().getEmail().equals("student1@localhost.localdomain"))
			{
				counter ++;
			}
		}
		
		//assert counter ==1 ;
*/
	}

}
