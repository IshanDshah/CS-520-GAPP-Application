package gapp.model.dao;

import java.util.List;

import gapp.model.Users;

public interface UsersDao {

	Users getUser(Integer user_id);

	List<Users> getUsers();

	Users saveUsers(Users users);
}